package com.example.demo.service.serviceImpl;

import com.example.demo.service.TencentID_corService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import static org.junit.Assert.*;
@RunWith(SpringRunner.class)
@SpringBootTest
public class TencentID_corServiceImplTest {
    @Autowired
    private TencentID_corService tencentID_corService;
    @Test
    public void getPhoto_Speak() throws Exception{
        String str = tencentID_corService.getPhoto_Speak("C:/Users/Administrator/Desktop/test.jpg","本地路径");
        String str2 = tencentID_corService.getPhoto_Speak("https://img.mukewang.com/5a2a45de0001164705600365.jpg","url路径");
        System.out.println(str);
        System.out.println(str2);
    }
}